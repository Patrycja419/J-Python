#!/usr/bin/python

import string;
word='WORD'
print'_'.join(word);

