Python 2.7.9 (default, Jun 29 2016, 13:08:31) 
[GCC 4.9.2] on linux2
Type "copyright", "credits" or "license()" for more information.
#2.1
>>> import __builtin__
>>> dir(__builtin__)
['ArithmeticError', 'AssertionError', 'AttributeError', 'BaseException', 'BufferError', 'BytesWarning', 'DeprecationWarning', 'EOFError', 'Ellipsis', 'EnvironmentError', 'Exception', 'False', 'FloatingPointError', 'FutureWarning', 'GeneratorExit', 'IOError', 'ImportError', 'ImportWarning', 'IndentationError', 'IndexError', 'KeyError', 'KeyboardInterrupt', 'LookupError', 'MemoryError', 'NameError', 'None', 'NotImplemented', 'NotImplementedError', 'OSError', 'OverflowError', 'PendingDeprecationWarning', 'ReferenceError', 'RuntimeError', 'RuntimeWarning', 'StandardError', 'StopIteration', 'SyntaxError', 'SyntaxWarning', 'SystemError', 'SystemExit', 'TabError', 'True', 'TypeError', 'UnboundLocalError', 'UnicodeDecodeError', 'UnicodeEncodeError', 'UnicodeError', 'UnicodeTranslateError', 'UnicodeWarning', 'UserWarning', 'ValueError', 'Warning', 'ZeroDivisionError', '__debug__', '__doc__', '__import__', '__name__', '__package__', 'abs', 'all', 'any', 'apply', 'basestring', 'bin', 'bool', 'buffer', 'bytearray', 'bytes', 'callable', 'chr', 'classmethod', 'cmp', 'coerce', 'compile', 'complex', 'copyright', 'credits', 'delattr', 'dict', 'dir', 'divmod', 'enumerate', 'eval', 'execfile', 'exit', 'file', 'filter', 'float', 'format', 'frozenset', 'getattr', 'globals', 'hasattr', 'hash', 'help', 'hex', 'id', 'input', 'int', 'intern', 'isinstance', 'issubclass', 'iter', 'len', 'license', 'list', 'locals', 'long', 'map', 'max', 'memoryview', 'min', 'next', 'object', 'oct', 'open', 'ord', 'pow', 'print', 'property', 'quit', 'range', 'raw_input', 'reduce', 'reload', 'repr', 'reversed', 'round', 'set', 'setattr', 'slice', 'sorted', 'staticmethod', 'str', 'sum', 'super', 'tuple', 'type', 'unichr', 'unicode', 'vars', 'xrange', 'zip']

#=============================
#2.2
>>> 5 == 5, 4 > 5
(True, False)
>>> x=5
>>> x==5 and 3
3
>>> x==4 and 3
False
>>> 
>>> 3 and x==5
True
>>> 3 and x==4
False
>>> 1<x<9
True
>>> isinstance(True, int)
True
>>> isinstance(True, bool)
True
#2.3
>>> int
<type 'int'>
>>> bool
<type 'bool'>
>>> 1, 3.45
(1, 3.45)
>>> 1
1
>>> str()
''
>>> repr()

Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>

>>> x='foo'
>>> repr(x)
"'foo'"
>>> x=3.2
>>> int(x)
3
>>> x=1
>>> float(x)
1.0
>>> x=-3
>>> abs(x)
3

>>> x=1
>>> y=2
>>> z=3
>>> (x**y)%z
1
>>> 2/2
1
>>> from __future__ import division
>>> 1/2
0.5
>>> 1//2
0
>>> x=3.444
>>> round(x)
3.0
>>> x=3.555
>>> int(x+0.5)
4
>>> 3/0

Traceback (most recent call last):
  File "<pyshell#58>", line 1, in <module>
    3/0
ZeroDivisionError: division by zero
#2.4
>>> len("napis")
5
>>> len(str(2 ** 10000))
3011
>>> "abc", 'abc'
('abc', 'abc')
>>> S = "ab"   'cd'
>>> "ab'cd", 'ab"cd'
("ab'cd", 'ab"cd')
>>> S = "a\tb\nc\"d"
>>> print len(S), S
7 a	b
c"d
>>> S = """jeden
dwa
trzy"""
>>> print S
jeden
dwa
trzy
>>> S="abrakadabra"
>>> S[2], S[-3], S[3:5], S[3:], S[:4]
('r', 'b', 'ak', 'akadabra', 'abra')
>>> L = ["a", "b", "c"]
>>> L[0] + L[1] + L[2]
'abc'
>>> L[0] + "=" + L[1] + "=" + L[2]
'a=b=c'
>>> "=".join(L)
'a=b=c'
#==============================
#2.5
>>> L = [3, "xyz", [10, 20]]
>>> len(L)
3
>>> L[1], L[1][0], L[2], L[2][1]
('xyz', 'x', [10, 20], 20)
>>> M = L
>>> L[1] = 5

>>> range(1)
[0]

#2.6

>>> dir(tuple)
['__add__', '__class__', '__contains__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__getslice__', '__gt__', '__hash__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
>>> dir(dict)
['__class__', '__cmp__', '__contains__', '__delattr__', '__delitem__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'clear', 'copy', 'fromkeys', 'get', 'has_key', 'items', 'iteritems', 'iterkeys', 'itervalues', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values', 'viewitems', 'viewkeys', 'viewvalues']
#2.8
>>> (KeyError)
<type 'exceptions.KeyError'>
#2.9

>>> S1 |= S2
>>> S1=3
>>> S2=4
>>> S1 |= S2
>>> S1 &= S2
>>> S1 -= S2
>>> S1 <= S2
True
>>> S1 >= S2
False
>>> S1 | S2
4
>>> S1 & S2
0
>>> S1 - S2
-4
>>> S1 ^ S2
4
>>> S1 -= S2
>>> X = frozenset([])
>>> X = frozenset(["b", "e", "t", "a"])
>>> X=2,3,4
>>> X = frozenset(["b", "e", "t", "a"])
>>> X = frozenset("beta")
>>> X = frozenset("ab") | set("bc")
>>> 34
34
>>> X = set("bc") | frozenset("ab")
>>> X = set("alfa")

>>> X = set("alfa")
>>> dir(set)
['__and__', '__class__', '__cmp__', '__contains__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__iand__', '__init__', '__ior__', '__isub__', '__iter__', '__ixor__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']
>>> X = frozenset([])
>>> dir(frozenset)
['__and__', '__class__', '__cmp__', '__contains__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'copy', 'difference', 'intersection', 'isdisjoint', 'issubset', 'issuperset', 'symmetric_difference', 'union']
>>> L = [1, 2, 2, 2, 3, 3]
>>> set(L)
set([1, 2, 3])
>>> L = list(set(L))
>>> 
