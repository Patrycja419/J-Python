#!/usr/bin/python

line="a bb ccc \ndddd eeee"
max(len(a)) for a in line.aplit())
max(line.split(), key=len)
