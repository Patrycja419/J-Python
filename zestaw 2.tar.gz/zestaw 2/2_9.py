def copy_file(infile_name, outfile_name):
    infile = open(infile_name, "r")
    outfile = open(outfile_name, "w")
    while True:
        text = infile.read(50)      # ograniczenie
        if text == "":
            break           # przerywa pętlę na końcu pliku
        outfile.write(text)
    infile.close()
    outfile.close()
