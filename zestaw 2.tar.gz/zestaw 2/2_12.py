#!/usr/bin/python

line="aa bb\n cc dd\n ee ff"
wynik=""
for a in line.split('\n')
	print wynik
