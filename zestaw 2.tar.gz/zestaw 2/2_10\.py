#!/usr/bin/ python
import string;
line="aa\nbb\ cc"
len(line.split());
