#!/usr/bin/python

str(10101010101010111111100).cout('0')
