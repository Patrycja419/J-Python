#!/usr/bin/python
line='GvR'
line.replace("GvR", "Guido van Rossum")
