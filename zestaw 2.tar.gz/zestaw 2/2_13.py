#!/usr/bin/python

line="aa bb\n cc dd"
sum(len(a) for a in line.split())
