#!/usr/bin/python
line="aa ggg bbb cccc ee"
sorted(line.split())#sortowanie alfabetycznie
sorted(line.split())# pod wzglede dlugosci znakow
