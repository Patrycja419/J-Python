#!/usr/bin/python
L=[4,5,7,23,5,57,30.49]
L.sort()
''.join(map(str, L))
