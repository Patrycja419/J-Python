#!/usr/bin/python
# -*- coding: utf-8 -*-

# przykladowa list sekwencji z tresci zadania
L = [[],[4],(1,2),[3,4],(5,6,7)];
print map(sum, L);
