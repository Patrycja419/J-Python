#!/usr/bin/python
for i in range(30):
 if(i%3 != 0):
  print i;
